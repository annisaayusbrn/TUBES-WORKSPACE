/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listJadwal;

/**
 *
 * @author Win10
 */
public class itemList extends javax.swing.JPanel{
    javax.swing.JLabel namaKegiatan;
    javax.swing.JLabel penyelenggara;
    
    public itemList(){
        initComponents();
    }
    
    
}
